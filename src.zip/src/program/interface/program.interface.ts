export interface ProgramPayload {
  id?: number;
  name: string;
  description: string;
  createdDate: Date;
  updatedDate: Date;
}
