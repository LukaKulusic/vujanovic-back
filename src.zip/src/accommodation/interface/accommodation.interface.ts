export interface AccommodationPayload {
  id?: number;
  name: string;
  createdDate: Date;
  updatedDate: Date;
}
