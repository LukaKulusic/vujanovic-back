export interface CountryPayload {
  id?: number;
  name: string;
  code: string;
}
