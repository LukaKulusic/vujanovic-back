export interface PaymentPayload {
  id?: number;
  type: string;
  createdDate: Date;
  updatedDate: Date;
}
