export enum PaymentType {
  'KES' = 'Kes',
  'FAKTURA' = 'Faktura',
  'AVANS' = 'Avans',
}
