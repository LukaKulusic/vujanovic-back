export interface FoodPayload {
  id?: number;
  name: string;
  type: string;
  createdDate: Date;
  updatedDate: Date;
}
