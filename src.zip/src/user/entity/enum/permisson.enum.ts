export enum UserPermission {
  User = 'User',
  //   CreateUser = 'CreateUser',
  //   UpdateUser = 'UpdateUser',
  //   GetUser = 'GetUser',
}
export enum FoodPermission {
  Food = 'Food',
  //   CreateFood = 'CreateFood',
  //   UpdateFood = 'UpdateFood',
  //   GetFood = 'GetFood',
}

export enum PaymentPermission {
  Payment = 'Payment',
}
export enum ProgramPermission {
  Program = 'Program',
}
export enum ReservationPermission {
  Reservation = 'Reservation',
}
export enum AccommodationPermission {
  Accommodation = 'Accommodation',
}
